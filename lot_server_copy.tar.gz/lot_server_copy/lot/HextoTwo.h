#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_ID 200

void HextoTwo(long int* id, int n, char* id_char);
