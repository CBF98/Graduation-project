#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>


#define ID "110101011010101EF023FFEA"
#define FIFO "/home/cbf/lot_server/fifo/"
#define FIFO_sign "/home/cbf/lot_server/fifo/sign.fifo"
