#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void obtain_lot_id(char* buff, char* destination, char* source);

