#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_ID 200

void HextoTwo(long int* id, int n, char* id_char);
void StringtoTwo(char* id_char, int n, char* id_two);
void Divide_OID(char* Ecode_id, char* lot_real_id);