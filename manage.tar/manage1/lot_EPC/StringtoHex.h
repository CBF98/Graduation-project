#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void StringtoHex(char* buff, long int* hex, int n);
