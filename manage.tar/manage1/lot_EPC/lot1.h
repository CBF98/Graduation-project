#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>


#define ID "13293A91E133D81123456789"
#define FIFO "/home/cbf/manage1/fifo/"
#define FIFO_sign "/home/cbf/manage1/fifo/sign.fifo"
#define lot_type "0"
