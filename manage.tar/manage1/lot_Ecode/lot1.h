#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>


#define ID "10064113736123456"
#define OID_ID "2.16.156.101818.11533251.12345678"
#define Ecode_type "1"
#define OID_type "2"
#define FIFO "/home/cbf/manage1/fifo/"
#define FIFO_sign "/home/cbf/manage1/fifo/sign.fifo"
