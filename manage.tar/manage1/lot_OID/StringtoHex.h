#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void StringtoTen(char* buff,int* hex, int n);
