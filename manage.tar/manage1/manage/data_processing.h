#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EPC_length 12
#define Ecode_length 9
#define OID_length 9
void obtain_lot_id(char* buff, char* destination, char* source);

