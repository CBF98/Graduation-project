#include <stdio.h>
#include <string.h>
#include <netinet/in.h>
#include <pthread.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <net/if_arp.h>
#include <sys/ioctl.h>

#define UDP_PORT_SERVER 8000
#define MAX_DATA 200
#define PURPOSE_IP "6.6.6.6"



void* socket_udp_server(void *arg);
void* socket_udp_client(void *arg);
